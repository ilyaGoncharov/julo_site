$('.carousel').carousel({
  interval: 12000,
  pause: 'hover',
  wrap: true,
});

